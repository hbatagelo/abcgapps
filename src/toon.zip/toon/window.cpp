#include "window.hpp"

#include "abcgOpenGLFunction.hpp"
#include "imfilebrowser.h"

void Window::onEvent(SDL_Event const &event) {
  glm::ivec2 mousePosition;
  SDL_GetMouseState(&mousePosition.x, &mousePosition.y);

  if (event.type == SDL_MOUSEMOTION) {
    m_trackBallModel.mouseMove(mousePosition);
    m_trackBallLight.mouseMove(mousePosition);
  }
  if (event.type == SDL_MOUSEBUTTONDOWN) {
    if (event.button.button == SDL_BUTTON_LEFT) {
      m_trackBallModel.mousePress(mousePosition);
    }
    if (event.button.button == SDL_BUTTON_RIGHT) {
      m_trackBallLight.mousePress(mousePosition);
    }
  }
  if (event.type == SDL_MOUSEBUTTONUP) {
    if (event.button.button == SDL_BUTTON_LEFT) {
      m_trackBallModel.mouseRelease(mousePosition);
    }
    if (event.button.button == SDL_BUTTON_RIGHT) {
      m_trackBallLight.mouseRelease(mousePosition);
    }
  }
  if (event.type == SDL_MOUSEWHEEL) {
    m_zoom += (event.wheel.y > 0 ? -1.0f : 1.0f) / 5.0f;
    m_zoom = glm::clamp(m_zoom, -1.5f, 1.0f);
  }
}

void Window::onCreate() {
  auto const assetsPath{abcg::Application::getAssetsPath()};

  resetParams();

  abcg::glEnable(GL_DEPTH_TEST);

  // Create programs
  for (auto const &name : m_shaderNames) {
    auto const program{
        abcg::createOpenGLProgram({{.source = assetsPath + name + ".vert",
                                    .stage = abcg::ShaderStage::Vertex},
                                   {.source = assetsPath + name + ".frag",
                                    .stage = abcg::ShaderStage::Fragment}})};
    m_programs.push_back(program);
  }

  // Create dilate program
  m_dilateProgram =
      abcg::createOpenGLProgram({{.source = assetsPath + "dilate.vert",
                                  .stage = abcg::ShaderStage::Vertex},
                                 {.source = assetsPath + "dilate.frag",
                                  .stage = abcg::ShaderStage::Fragment}});

  // Load model
  m_model.loadObj(assetsPath + "bunny.obj");
  m_model.setupVAO(m_programs.at(m_currentProgramIndex));

  m_trianglesToDraw = m_model.getNumTriangles();
}

void Window::onUpdate() {
  m_modelMatrix = m_trackBallModel.getRotation();

  m_viewMatrix =
      glm::lookAt(glm::vec3(0.0f, 0.0f, 2.0f + m_zoom),
                  glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
}

void Window::onPaint() {
  abcg::glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  abcg::glViewport(0, 0, m_viewportSize.x, m_viewportSize.y);

  auto const program{m_programs.at(m_currentProgramIndex)};

  // For the toon shader we first render a dilated version of the model with
  // front-face culling and no depth write. This will create the model's
  // outline.
  if (m_usingToonShader) {
    auto savedCullFaceState{abcg::glIsEnabled(GL_CULL_FACE)};

    // Enable front-face culling
    abcg::glCullFace(GL_FRONT);
    abcg::glEnable(GL_CULL_FACE);

    // Disable depth writing
    abcg::glDepthMask(GL_FALSE);

    abcg::glUseProgram(m_dilateProgram);

    // Get location of uniform variables
    auto const modelViewMatrixLoc{
        abcg::glGetUniformLocation(m_dilateProgram, "modelViewMatrix")};
    auto const projMatrixLoc{
        abcg::glGetUniformLocation(m_dilateProgram, "projMatrix")};
    auto const normalMatrixLoc{
        abcg::glGetUniformLocation(m_dilateProgram, "normalMatrix")};
    auto const thicknessLoc{
        abcg::glGetUniformLocation(m_dilateProgram, "thickness")};
    auto const colorLoc{abcg::glGetUniformLocation(m_dilateProgram, "color")};

    // Set uniform variables
    auto const modelViewMatrix{m_viewMatrix * m_modelMatrix};
    abcg::glUniformMatrix4fv(modelViewMatrixLoc, 1, GL_FALSE,
                             &modelViewMatrix[0][0]);
    auto const normalMatrix{glm::inverseTranspose(glm::mat3(modelViewMatrix))};
    abcg::glUniformMatrix3fv(normalMatrixLoc, 1, GL_FALSE, &normalMatrix[0][0]);
    abcg::glUniformMatrix4fv(projMatrixLoc, 1, GL_FALSE, &m_projMatrix[0][0]);
    abcg::glUniform1f(thicknessLoc, m_dilateThickness);
    abcg::glUniform4fv(colorLoc, 1, &m_dilateColor[0]);

    // Render
    m_model.setupVAO(m_dilateProgram);
    m_model.render(m_trianglesToDraw);

    // Enable depth writing
    abcg::glDepthMask(GL_TRUE);

    // Back to previous face-culling settings
    if (!savedCullFaceState) {
      abcg::glDisable(GL_CULL_FACE);
    }

    // Set up VAO for the next pass
    m_model.setupVAO(program);
  }

  // Use currently selected program
  abcg::glUseProgram(program);

  // Get location of uniform variables
  auto const viewMatrixLoc{abcg::glGetUniformLocation(program, "viewMatrix")};
  auto const projMatrixLoc{abcg::glGetUniformLocation(program, "projMatrix")};
  auto const modelMatrixLoc{abcg::glGetUniformLocation(program, "modelMatrix")};
  auto const normalMatrixLoc{
      abcg::glGetUniformLocation(program, "normalMatrix")};
  auto const lightDirLoc{
      abcg::glGetUniformLocation(program, "lightDirWorldSpace")};
  auto const shininessLoc{abcg::glGetUniformLocation(program, "shininess")};
  auto const IaLoc{abcg::glGetUniformLocation(program, "Ia")};
  auto const IdLoc{abcg::glGetUniformLocation(program, "Id")};
  auto const IsLoc{abcg::glGetUniformLocation(program, "Is")};
  auto const KaLoc{abcg::glGetUniformLocation(program, "Ka")};
  auto const KdLoc{abcg::glGetUniformLocation(program, "Kd")};
  auto const KsLoc{abcg::glGetUniformLocation(program, "Ks")};

  // Set uniform variables that have the same value for every model
  abcg::glUniformMatrix4fv(viewMatrixLoc, 1, GL_FALSE, &m_viewMatrix[0][0]);
  abcg::glUniformMatrix4fv(projMatrixLoc, 1, GL_FALSE, &m_projMatrix[0][0]);

  auto const lightDirRotated{m_trackBallLight.getRotation() * m_lightDir};
  abcg::glUniform4fv(lightDirLoc, 1, &lightDirRotated.x);
  abcg::glUniform4fv(IaLoc, 1, &m_Ia.x);
  abcg::glUniform4fv(IdLoc, 1, &m_Id.x);
  abcg::glUniform4fv(IsLoc, 1, &m_Is.x);

  // Set uniform variables for the current model
  abcg::glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, &m_modelMatrix[0][0]);
  abcg::glUniform4fv(KaLoc, 1, &m_Ka.x);
  abcg::glUniform4fv(KdLoc, 1, &m_Kd.x);
  abcg::glUniform4fv(KsLoc, 1, &m_Ks.x);
  abcg::glUniform1f(shininessLoc, m_shininess);

  auto const modelViewMatrix{glm::mat3(m_viewMatrix * m_modelMatrix)};
  auto const normalMatrix{glm::inverseTranspose(modelViewMatrix)};
  abcg::glUniformMatrix3fv(normalMatrixLoc, 1, GL_FALSE, &normalMatrix[0][0]);

  // Set uniform variables for toon shader
  if (m_usingToonShader) {
    auto const diffuseThresholdLoc{
        abcg::glGetUniformLocation(program, "diffuseThreshold")};
    auto const specularThresholdLoc{
        abcg::glGetUniformLocation(program, "specularThreshold")};
    auto const rimThresholdLoc{
        abcg::glGetUniformLocation(program, "rimThreshold")};

    abcg::glUniform1f(diffuseThresholdLoc, m_diffuseThreshold);
    abcg::glUniform1f(specularThresholdLoc, m_specularThreshold);
    abcg::glUniform1f(rimThresholdLoc, m_rimThreshold);
  }

  m_model.render(m_trianglesToDraw);

  abcg::glUseProgram(0);
}

void Window::onPaintUI() {
  abcg::OpenGLWindow::onPaintUI();

  auto const scaledWidth{gsl::narrow_cast<int>(m_viewportSize.x * 0.8f)};
  auto const scaledHeight{gsl::narrow_cast<int>(m_viewportSize.y * 0.8f)};

  // File browser for models
  static ImGui::FileBrowser fileDialogModel;
  fileDialogModel.SetTitle("Load 3D Model");
  fileDialogModel.SetTypeFilters({".obj"});
  fileDialogModel.SetWindowSize(scaledWidth, scaledHeight);

#if defined(__EMSCRIPTEN__)
  auto const assetsPath{abcg::Application::getAssetsPath()};
  fileDialogModel.SetPwd(assetsPath);
#endif

  // Create a window for the other widgets
  {
    auto const widgetSize{ImVec2(222, 168)};
    ImGui::SetNextWindowPos(ImVec2(m_viewportSize.x - widgetSize.x - 5, 5));
    ImGui::SetNextWindowSize(widgetSize);
    ImGui::Begin("Widget window", nullptr, ImGuiWindowFlags_NoDecoration);

    // Slider will be stretched horizontally
    ImGui::PushItemWidth(widgetSize.x - 16);
    ImGui::SliderInt(" ", &m_trianglesToDraw, 0, m_model.getNumTriangles(),
                     "%d triangles");
    ImGui::PopItemWidth();

    static bool faceCulling{};
    ImGui::Checkbox("Back-face culling", &faceCulling);

    if (faceCulling) {
      abcg::glEnable(GL_CULL_FACE);
    } else {
      abcg::glDisable(GL_CULL_FACE);
    }

    // CW/CCW combo box
    {
      static std::size_t currentIndex{};
      std::vector<std::string> const comboItems{"CCW", "CW"};

      ImGui::PushItemWidth(120);
      if (ImGui::BeginCombo("Front face",
                            comboItems.at(currentIndex).c_str())) {
        for (auto const index : iter::range(comboItems.size())) {
          auto const isSelected{currentIndex == index};
          if (ImGui::Selectable(comboItems.at(index).c_str(), isSelected))
            currentIndex = index;
          if (isSelected)
            ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
      }
      ImGui::PopItemWidth();

      if (currentIndex == 0) {
        abcg::glFrontFace(GL_CCW);
      } else {
        abcg::glFrontFace(GL_CW);
      }
    }

    // Projection combo box
    {
      static std::size_t currentIndex{};
      std::vector<std::string> comboItems{"Perspective", "Orthographic"};

      ImGui::PushItemWidth(120);
      if (ImGui::BeginCombo("Projection",
                            comboItems.at(currentIndex).c_str())) {
        for (auto const index : iter::range(comboItems.size())) {
          auto const isSelected{currentIndex == index};
          if (ImGui::Selectable(comboItems.at(index).c_str(), isSelected))
            currentIndex = index;
          if (isSelected)
            ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
      }
      ImGui::PopItemWidth();

      auto const aspect{gsl::narrow<float>(m_viewportSize.x) /
                        gsl::narrow<float>(m_viewportSize.y)};

      if (currentIndex == 0) {
        m_projMatrix =
            glm::perspective(glm::radians(45.0f), aspect, 0.1f, 5.0f);
      } else {
        m_projMatrix =
            glm::ortho(-1.0f * aspect, 1.0f * aspect, -1.0f, 1.0f, 0.1f, 5.0f);
      }
    }

    // Shader combo box
    {
      static std::size_t currentIndex{};

      ImGui::PushItemWidth(120);
      if (ImGui::BeginCombo("Shader", m_shaderNames.at(currentIndex))) {
        for (auto const index : iter::range(m_shaderNames.size())) {
          auto const isSelected{currentIndex == index};
          if (ImGui::Selectable(m_shaderNames.at(index), isSelected))
            currentIndex = index;
          if (isSelected)
            ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
      }
      ImGui::PopItemWidth();

      // Set up VAO if shader program has changed
      if (gsl::narrow<int>(currentIndex) != m_currentProgramIndex) {
        m_currentProgramIndex = gsl::narrow<int>(currentIndex);
        m_model.setupVAO(m_programs.at(m_currentProgramIndex));
        resetParams();
      }
    }

    if (ImGui::Button("Load 3D Model...", ImVec2(-1, -1))) {
      fileDialogModel.Open();
    }

    ImGui::End();
  }

  // Create window for light sources
  if (m_currentProgramIndex < 4) {
    auto const widgetSize{ImVec2(222, 244 + (m_usingToonShader ? 172 : 0))};

    ImGui::SetNextWindowPos(ImVec2(m_viewportSize.x - widgetSize.x - 5,
                                   m_viewportSize.y - widgetSize.y - 5));
    ImGui::SetNextWindowSize(widgetSize);
    ImGui::Begin(" ", nullptr, ImGuiWindowFlags_NoDecoration);

    ImGui::Text("Light properties");

    // Slider to control light properties
    ImGui::PushItemWidth(widgetSize.x - 36);
    ImGui::ColorEdit3("Ia", &m_Ia.x, ImGuiColorEditFlags_Float);
    ImGui::ColorEdit3("Id", &m_Id.x, ImGuiColorEditFlags_Float);
    ImGui::ColorEdit3("Is", &m_Is.x, ImGuiColorEditFlags_Float);
    ImGui::PopItemWidth();

    ImGui::Spacing();

    ImGui::Text("Material properties");

    // Slider to control material properties
    ImGui::PushItemWidth(widgetSize.x - 36);
    ImGui::ColorEdit3("Ka", &m_Ka.x, ImGuiColorEditFlags_Float);
    ImGui::ColorEdit3("Kd", &m_Kd.x, ImGuiColorEditFlags_Float);
    ImGui::ColorEdit3("Ks", &m_Ks.x, ImGuiColorEditFlags_Float);
    ImGui::PopItemWidth();

    // Slider to control the specular shininess
    ImGui::PushItemWidth(widgetSize.x - 16);
    ImGui::SliderFloat("##shininess", &m_shininess, 0.0f, 500.0f,
                       "shininess: %.1f");
    ImGui::PopItemWidth();

    // UI for toon shader
    if (m_usingToonShader) {
      ImGui::Spacing();

      ImGui::Text("Toon outline");
      ImGui::PushItemWidth(widgetSize.x - 16);
      ImGui::SliderFloat("##thickness", &m_dilateThickness, 0.0f, 0.05f,
                         "thickness: %.3f");
      ImGui::PopItemWidth();

      ImGui::PushItemWidth(widgetSize.x - 16);
      ImGui::ColorEdit3("##color", &m_dilateColor.x, ImGuiColorEditFlags_Float);
      ImGui::PopItemWidth();

      ImGui::Spacing();

      ImGui::Text("Toon thresholds");
      ImGui::PushItemWidth(widgetSize.x - 16);
      ImGui::SliderFloat("##diffThr", &m_diffuseThreshold, 0.0f,
                         m_specularThreshold, "diffuse: %.2f");
      ImGui::SliderFloat("##specThr", &m_specularThreshold, m_diffuseThreshold,
                         1.0f, "specular: %.2f");
      ImGui::SliderFloat("##rimThr", &m_rimThreshold, 0.0f, 1.0f, "rim: %.2f");

      ImGui::PopItemWidth();
    }

    ImGui::End();
  }

  fileDialogModel.Display();

  if (fileDialogModel.HasSelected()) {
    // Load model
    m_model.loadObj(fileDialogModel.GetSelected().string());
    m_model.setupVAO(m_programs.at(m_currentProgramIndex));
    m_trianglesToDraw = m_model.getNumTriangles();
    fileDialogModel.ClearSelected();
  }
}

void Window::onResize(glm::ivec2 const &size) {
  m_viewportSize = size;
  m_trackBallModel.resizeViewport(size);
  m_trackBallLight.resizeViewport(size);
}

void Window::onDestroy() {
  m_model.destroy();
  abcg::glDeleteProgram(m_dilateProgram);
  for (auto const &program : m_programs) {
    abcg::glDeleteProgram(program);
  }
}

void Window::resetParams() {
  m_usingToonShader =
      std::string(m_shaderNames.at(m_currentProgramIndex)) == "toon";

  if (m_usingToonShader) {
    glClearColor(1, 1, 1, 1);
    m_Ka = glm::vec4(0.35f);
    m_Kd = glm::vec4(0.45f);
    m_Ks = glm::vec4(1.0f);
  } else {
    glClearColor(0, 0, 0, 1);
    m_Ka = glm::vec4(0.1f, 0.1f, 0.1f, 1.0f);
    m_Kd = glm::vec4(0.7f, 0.7f, 0.7f, 1.0f);
    m_Ks = glm::vec4(1.0f);
  }
}