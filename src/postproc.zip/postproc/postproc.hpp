#ifndef POSTPROC_HPP_
#define POSTPROC_HPP_

#include "abcgOpenGL.hpp"
#include "abcgTimer.hpp"

class PostProc {
public:
  void create(std::string_view shaderName);
  void paint(GLuint textureID, glm::ivec2 const &size);
  void destroy();

private:
  GLuint m_VAO{};
  GLuint m_VBO{};
  GLuint m_program{};

  GLint m_timeLoc{};
  GLint m_resolutionLoc{};

  abcg::Timer m_timer;
};

#endif