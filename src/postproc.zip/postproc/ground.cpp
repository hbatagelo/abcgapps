#include "ground.hpp"
#include "model.hpp"

void Ground::create(GLuint program) {
  // Unit quad on the xz plane (CCW)
  std::array<Vertex, 4> vertices{
      {{.position = {-0.5f, 0.0f, -0.5f}, .normal = {0, 1, 0}},
       {.position = {-0.5f, 0.0f, +0.5f}, .normal = {0, 1, 0}},
       {.position = {+0.5f, 0.0f, -0.5f}, .normal = {0, 1, 0}},
       {.position = {+0.5f, 0.0f, +0.5f}, .normal = {0, 1, 0}}}};

  // Generate VBO
  abcg::glGenBuffers(1, &m_VBO);
  abcg::glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
  abcg::glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices.data(),
                     GL_STATIC_DRAW);
  abcg::glBindBuffer(GL_ARRAY_BUFFER, 0);

  // Create VAO and bind vertex attributes
  abcg::glGenVertexArrays(1, &m_VAO);
  abcg::glBindVertexArray(m_VAO);
  abcg::glBindBuffer(GL_ARRAY_BUFFER, m_VBO);

  auto const positionAttribute{
      abcg::glGetAttribLocation(program, "inPosition")};
  if (positionAttribute >= 0) {
    abcg::glEnableVertexAttribArray(positionAttribute);
    abcg::glVertexAttribPointer(positionAttribute, 3, GL_FLOAT, GL_FALSE,
                                sizeof(Vertex), nullptr);
  }

  auto const normalAttribute{abcg::glGetAttribLocation(program, "inNormal")};
  if (normalAttribute >= 0) {
    abcg::glEnableVertexAttribArray(normalAttribute);
    auto const offset{offsetof(Vertex, normal)};
    abcg::glVertexAttribPointer(normalAttribute, 3, GL_FLOAT, GL_FALSE,
                                sizeof(Vertex),
                                reinterpret_cast<void *>(offset));
  }

  // End of binding
  abcg::glBindBuffer(GL_ARRAY_BUFFER, 0);
  abcg::glBindVertexArray(0);

  // Save location of uniform variables
  m_modelMatrixLoc = abcg::glGetUniformLocation(program, "modelMatrix");
  m_normalMatrixLoc = abcg::glGetUniformLocation(program, "normalMatrix");
  m_KdLoc = abcg::glGetUniformLocation(program, "Kd");
  m_shininessLoc = abcg::glGetUniformLocation(program, "shininess");
}

void Ground::paint(glm::mat4 const &viewMatrix) {
  abcg::glBindVertexArray(m_VAO);

  // Draw a grid of 2N+1 x 2N+1 tiles on the xz plane, centered around the
  // origin
  auto const N{10};
  for (auto const z : iter::range(-N, N + 1)) {
    for (auto const x : iter::range(-N, N + 1)) {
      // Set model matrix as a translation matrix
      glm::mat4 modelMatrix{1.0f};
      modelMatrix = glm::translate(modelMatrix, glm::vec3(x, 0.0f, z));
      abcg::glUniformMatrix4fv(m_modelMatrixLoc, 1, GL_FALSE,
                               &modelMatrix[0][0]);

      // Set normal matrix
      auto const normalMatrix{
          glm::inverseTranspose(glm::mat3(viewMatrix * modelMatrix))};
      abcg::glUniformMatrix3fv(m_normalMatrixLoc, 1, GL_FALSE,
                               &normalMatrix[0][0]);

      // Set color (checkerboard pattern)
      auto const gray{(z + x) % 2 == 0 ? 1.0f : 0.75f};
      abcg::glUniform4f(m_KdLoc, gray, gray, gray, 1.0f);

      abcg::glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    }
  }

  abcg::glBindVertexArray(0);
}

void Ground::destroy() {
  abcg::glDeleteBuffers(1, &m_VBO);
  abcg::glDeleteVertexArrays(1, &m_VAO);
}