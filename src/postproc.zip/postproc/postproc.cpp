#include "postproc.hpp"

void PostProc::create(std::string_view shaderName) {
  auto const &assetsPath{abcg::Application::getAssetsPath()};

  // Create program
  m_program = abcg::createOpenGLProgram(
      {{.source = assetsPath + shaderName.data() + ".vert",
        .stage = abcg::ShaderStage::Vertex},
       {.source = assetsPath + shaderName.data() + ".frag",
        .stage = abcg::ShaderStage::Fragment}});

  m_timeLoc = glGetUniformLocation(m_program, "uTime");
  m_resolutionLoc = glGetUniformLocation(m_program, "uResolution");

  // Quad data
  struct Vertex {
    glm::vec2 position;
    glm::vec2 texCoord;
  };

  std::array const vertices{Vertex{.position = {-1, +1}, .texCoord = {0, 1}},
                            Vertex{.position = {-1, -1}, .texCoord = {0, 0}},
                            Vertex{.position = {+1, +1}, .texCoord = {1, 1}},
                            Vertex{.position = {+1, -1}, .texCoord = {1, 0}}};
  // Generate VBO
  abcg::glGenBuffers(1, &m_VBO);
  abcg::glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
  abcg::glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices.data(),
                     GL_STATIC_DRAW);

  // Create VAO
  abcg::glGenVertexArrays(1, &m_VAO);
  abcg::glBindVertexArray(m_VAO);

  // Set up vertex attributes
  auto setAttribute{[](auto program, auto const &attributeName, auto numFloats,
                       auto stride, auto offset) {
    auto const location{abcg::glGetAttribLocation(program, attributeName)};
    abcg::glEnableVertexAttribArray(location);
    abcg::glVertexAttribPointer(location, numFloats, GL_FLOAT, GL_FALSE, stride,
                                reinterpret_cast<void *>(offset));
  }};

  auto const stride{sizeof(Vertex)};
  setAttribute(m_program, "inPosition", 2, stride, 0);
  setAttribute(m_program, "inTexCoord", 2, stride, offsetof(Vertex, texCoord));

  // End of binding to current VAO
  abcg::glBindBuffer(GL_ARRAY_BUFFER, 0);
  abcg::glBindVertexArray(0);
}

void PostProc::paint(GLuint textureID, glm::ivec2 const &size) {
  abcg::glDisable(GL_DEPTH_TEST);

  abcg::glActiveTexture(GL_TEXTURE0);
  abcg::glBindTexture(GL_TEXTURE_2D, textureID);

  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

  abcg::glUseProgram(m_program);
  abcg::glBindVertexArray(m_VAO);

  abcg::glUniform1f(m_timeLoc, m_timer.elapsed());
  abcg::glUniform2iv(m_resolutionLoc, 1, &size.x);

  // Draw quad
  abcg::glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

  abcg::glBindVertexArray(0);
  abcg::glUseProgram(0);
}

void PostProc::destroy() {
  abcg::glDeleteProgram(m_program);
  abcg::glDeleteBuffers(1, &m_VBO);
  abcg::glDeleteVertexArrays(1, &m_VAO);
}