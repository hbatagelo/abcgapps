#ifndef GROUND_HPP_
#define GROUND_HPP_

#include "abcgOpenGL.hpp"

class Ground {
public:
  void create(GLuint program);
  void paint(glm::mat4 const &viewMatrix);
  void destroy();

private:
  GLuint m_VAO{};
  GLuint m_VBO{};

  GLint m_modelMatrixLoc{};
  GLint m_normalMatrixLoc{};
  GLint m_KdLoc{};
  GLint m_shininessLoc{};
};

#endif