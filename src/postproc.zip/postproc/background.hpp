#ifndef BACKGROUND_HPP_
#define BACKGROUND_HPP_

#include "abcgOpenGL.hpp"

class Background {
public:
  void create();
  void paint();
  void destroy();

private:
  GLuint m_VAO{};
  GLuint m_VBO{};
  GLuint m_program{};
};

#endif