#include "background.hpp"

void Background::create() {
  auto const &assetsPath{abcg::Application::getAssetsPath()};

  // Create program
  m_program =
      abcg::createOpenGLProgram({{.source = assetsPath + "background.vert",
                                  .stage = abcg::ShaderStage::Vertex},
                                 {.source = assetsPath + "background.frag",
                                  .stage = abcg::ShaderStage::Fragment}});

  // Quad data
  struct Vertex {
    glm::vec2 position;
    glm::vec2 texCoord;
  };

  std::array const vertices{Vertex{.position = {-1, +1}, .texCoord = {0, 1}},
                            Vertex{.position = {-1, -1}, .texCoord = {0, 0}},
                            Vertex{.position = {+1, +1}, .texCoord = {1, 1}},
                            Vertex{.position = {+1, -1}, .texCoord = {1, 0}}};
  // Generate VBO
  abcg::glGenBuffers(1, &m_VBO);
  abcg::glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
  abcg::glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices.data(),
                     GL_STATIC_DRAW);

  // Create VAO
  abcg::glGenVertexArrays(1, &m_VAO);
  abcg::glBindVertexArray(m_VAO);

  // Set up vertex attributes
  auto setAttribute{[](auto program, auto const &attributeName, auto numFloats,
                       auto stride, auto offset) {
    auto const location{abcg::glGetAttribLocation(program, attributeName)};
    abcg::glEnableVertexAttribArray(location);
    abcg::glVertexAttribPointer(location, numFloats, GL_FLOAT, GL_FALSE, stride,
                                reinterpret_cast<void *>(offset));
  }};

  auto const stride{sizeof(Vertex)};
  setAttribute(m_program, "inPosition", 2, stride, 0);
  setAttribute(m_program, "inTexCoord", 2, stride, offsetof(Vertex, texCoord));

  // End of binding to current VAO
  abcg::glBindBuffer(GL_ARRAY_BUFFER, 0);
  abcg::glBindVertexArray(0);
}

void Background::paint() {
  abcg::glUseProgram(m_program);
  abcg::glBindVertexArray(m_VAO);

  // Draw quad
  abcg::glDepthFunc(GL_LEQUAL);
  abcg::glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
  abcg::glDepthFunc(GL_LESS);

  abcg::glBindVertexArray(0);
  abcg::glUseProgram(0);
}

void Background::destroy() {
  abcg::glDeleteProgram(m_program);
  abcg::glDeleteBuffers(1, &m_VBO);
  abcg::glDeleteVertexArrays(1, &m_VAO);
}