#include "window.hpp"
#include "abcgOpenGLFunction.hpp"

#include <imgui.h>
#include <unordered_map>

void Window::onEvent(SDL_Event const &event) {
  if (event.type == SDL_KEYDOWN) {
    if (event.key.keysym.sym == SDLK_UP || event.key.keysym.sym == SDLK_w)
      m_dollySpeed = 1.0f;
    if (event.key.keysym.sym == SDLK_DOWN || event.key.keysym.sym == SDLK_s)
      m_dollySpeed = -1.0f;
    if (event.key.keysym.sym == SDLK_LEFT || event.key.keysym.sym == SDLK_a)
      m_panSpeed = -1.0f;
    if (event.key.keysym.sym == SDLK_RIGHT || event.key.keysym.sym == SDLK_d)
      m_panSpeed = 1.0f;
    if (event.key.keysym.sym == SDLK_q)
      m_truckSpeed = -1.0f;
    if (event.key.keysym.sym == SDLK_e)
      m_truckSpeed = 1.0f;
  }
  if (event.type == SDL_KEYUP) {
    if ((event.key.keysym.sym == SDLK_UP || event.key.keysym.sym == SDLK_w) &&
        m_dollySpeed > 0)
      m_dollySpeed = 0.0f;
    if ((event.key.keysym.sym == SDLK_DOWN || event.key.keysym.sym == SDLK_s) &&
        m_dollySpeed < 0)
      m_dollySpeed = 0.0f;
    if ((event.key.keysym.sym == SDLK_LEFT || event.key.keysym.sym == SDLK_a) &&
        m_panSpeed < 0)
      m_panSpeed = 0.0f;
    if ((event.key.keysym.sym == SDLK_RIGHT ||
         event.key.keysym.sym == SDLK_d) &&
        m_panSpeed > 0)
      m_panSpeed = 0.0f;
    if (event.key.keysym.sym == SDLK_q && m_truckSpeed < 0)
      m_truckSpeed = 0.0f;
    if (event.key.keysym.sym == SDLK_e && m_truckSpeed > 0)
      m_truckSpeed = 0.0f;
  }
}

void Window::onCreate() {
  auto const &assetsPath{abcg::Application::getAssetsPath()};

  abcg::glClearColor(0, 0, 0, 1);

  // Create program
  m_program =
      abcg::createOpenGLProgram({{.source = assetsPath + "lookat.vert",
                                  .stage = abcg::ShaderStage::Vertex},
                                 {.source = assetsPath + "lookat.frag",
                                  .stage = abcg::ShaderStage::Fragment}});
  m_modelMatrixLoc = abcg::glGetUniformLocation(m_program, "modelMatrix");
  m_normalMatrixLoc = abcg::glGetUniformLocation(m_program, "normalMatrix");
  m_KdLoc = abcg::glGetUniformLocation(m_program, "Kd");

  m_background.create();
  m_ground.create(m_program);
  m_postProc.create("crt");

  // Load model
  m_model.loadObj(assetsPath + "bunny.obj", false);
  m_model.setupVAO(m_program);

  // Create framebuffer object
  abcg::glGenFramebuffers(1, &m_FBO);
}

void Window::onUpdate() {
  auto const deltaTime{gsl::narrow_cast<float>(getDeltaTime())};

  m_camera.dolly(m_dollySpeed * deltaTime);
  m_camera.truck(m_truckSpeed * deltaTime);
  m_camera.pan(m_panSpeed * deltaTime);
}

void Window::onPaint() {
  abcg::glClear(GL_COLOR_BUFFER_BIT);

  abcg::glViewport(0, 0, m_viewportSize.x, m_viewportSize.y);

  if (m_postProcess) {
    // 1st pass: render to texture
    abcg::glBindFramebuffer(GL_FRAMEBUFFER, m_FBO);
    renderScene();

    // 2nd pass: apply post-processing effect and render to main framebuffer
    abcg::glBindFramebuffer(GL_FRAMEBUFFER, 0);
    m_postProc.paint(m_colorBufferTexture, m_viewportSize);
  } else {
    // Single pass: render directly to main framebuffer
    renderScene();
  }
}

void Window::onPaintUI() {
  abcg::OpenGLWindow::onPaintUI();
  {
    auto const widgetSize{ImVec2(160, 38)};
    ImGui::SetNextWindowPos(ImVec2(m_viewportSize.x - widgetSize.x - 5, 5));
    ImGui::SetNextWindowSize(widgetSize);
    ImGui::Begin("Widget window", nullptr, ImGuiWindowFlags_NoDecoration);
    ImGui::Checkbox("Post-processing", &m_postProcess);
    ImGui::End();
  }
}

void Window::onResize(glm::ivec2 const &size) {
  m_viewportSize = size;
  m_camera.computeProjectionMatrix(size);

  destroyFBOAttachments();
  createFBOAttachments();
}

void Window::onDestroy() {
  abcg::glDeleteTextures(1, &m_colorBufferTexture);
  abcg::glDeleteFramebuffers(1, &m_FBO);

  m_model.destroy();
  m_ground.destroy();
  m_postProc.destroy();

  abcg::glDeleteProgram(m_program);
}

void Window::renderScene() {
  abcg::glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  abcg::glEnable(GL_DEPTH_TEST);

  m_background.paint();

  // Helper lambda to return location of a uniform variable
  auto getLocation{[this](auto name) {
    return abcg::glGetUniformLocation(m_program, name);
  }};

  abcg::glUseProgram(m_program);

  // Set uniform variables shared by all objects
  abcg::glUniformMatrix4fv(getLocation("viewMatrix"), 1, GL_FALSE,
                           &m_camera.getViewMatrix()[0][0]);
  abcg::glUniformMatrix4fv(getLocation("projMatrix"), 1, GL_FALSE,
                           &m_camera.getProjMatrix()[0][0]);
  abcg::glUniform4fv(getLocation("lightDirWorldSpace"), 1, &m_lightDir.x);
  abcg::glUniform4fv(getLocation("Ia"), 1, &m_Ia.x);
  abcg::glUniform4fv(getLocation("Id"), 1, &m_Id.x);
  abcg::glUniform4fv(getLocation("Is"), 1, &m_Is.x);
  abcg::glUniform4f(getLocation("Ka"), 1.0f, 1.0f, 1.0f, 1.0f);
  abcg::glUniform4f(getLocation("Ks"), 1.0f, 1.0f, 1.0f, 1.0f);
  abcg::glUniform1f(getLocation("shininess"), 25.0f);

  // Helper lambda to set uniforms of the current object
  auto setUniforms{[this](glm::mat4 const &modelMatrix,
                          glm::vec4 const &color) {
    auto const normalMatrix{glm::inverseTranspose(
        glm::mat3(m_camera.getViewMatrix() * modelMatrix))};
    abcg::glUniformMatrix4fv(m_modelMatrixLoc, 1, GL_FALSE, &modelMatrix[0][0]);
    abcg::glUniformMatrix3fv(m_normalMatrixLoc, 1, GL_FALSE,
                             &normalMatrix[0][0]);
    abcg::glUniform4fv(m_KdLoc, 1, &color.x);
  }};

  // Draw white bunny
  glm::mat4 model{1.0f};
  model = glm::translate(model, glm::vec3(-1, 0, 0));
  model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0, 1, 0));
  model = glm::scale(model, glm::vec3(0.5f));
  setUniforms(model, {1.0f, 1.0f, 1.0f, 1.0f});
  m_model.render();

  // Draw yellow bunny
  model = glm::translate(glm::mat4{1.0}, glm::vec3(0.0f, 0.0f, -1.0f));
  model = glm::scale(model, glm::vec3(0.5f));
  setUniforms(model, {1.0f, 0.8f, 0.0f, 1.0f});
  m_model.render();

  // Draw blue bunny
  model = glm::translate(glm::mat4{1.0}, glm::vec3(1.0f, 0.0f, 0.0f));
  model = glm::rotate(model, glm::radians(-90.0f), glm::vec3(0, 1, 0));
  model = glm::scale(model, glm::vec3(0.5f));
  setUniforms(model, {0.0f, 0.8f, 1.0f, 1.0f});
  m_model.render();

  // Draw red bunny
  model = glm::scale(glm::mat4{1.0}, glm::vec3(0.1f));
  setUniforms(model, {1.0f, 0.25f, 0.25f, 1.0f});
  m_model.render();

  // Draw ground
  m_ground.paint(m_camera.getViewMatrix());
}

// Create textures to be used as attachments of the FBO
void Window::createFBOAttachments() {
  auto const &[width, height]{std::pair(m_viewportSize.x, m_viewportSize.y)};
  if (width == 0 || height == 0)
    return;

  // Create color buffer texture
  abcg::glGenTextures(1, &m_colorBufferTexture);
  abcg::glBindTexture(GL_TEXTURE_2D, m_colorBufferTexture);
  abcg::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB,
                     GL_UNSIGNED_BYTE, nullptr);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  abcg::glBindTexture(GL_TEXTURE_2D, 0);

  // Create depth buffer texture using RBO
  abcg::glGenRenderbuffers(1, &m_RBO);
  abcg::glBindRenderbuffer(GL_RENDERBUFFER, m_RBO);
  abcg::glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, width,
                              height);
  abcg::glBindRenderbuffer(GL_RENDERBUFFER, 0);

  // Check if FBO and its attachments satisfy the minimum requirements
  if (m_FBO > 0) {
    abcg::glBindFramebuffer(GL_FRAMEBUFFER, m_FBO);

    // Attach color buffer texture
    abcg::glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                                 GL_TEXTURE_2D, m_colorBufferTexture, 0);
    // Attach RBO
    abcg::glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT,
                                    GL_RENDERBUFFER, m_RBO);

    if (abcg::glCheckFramebufferStatus(GL_FRAMEBUFFER) !=
        GL_FRAMEBUFFER_COMPLETE) {
      throw abcg::RuntimeError("Could not create framebuffer object");
    }

    abcg::glBindFramebuffer(GL_FRAMEBUFFER, 0);
  }
}

void Window::destroyFBOAttachments() {
  if (m_colorBufferTexture > 0) {
    abcg::glDeleteTextures(1, &m_colorBufferTexture);
    m_colorBufferTexture = 0;
  }
  if (m_RBO > 0) {
    abcg::glDeleteRenderbuffers(1, &m_RBO);
    m_RBO = 0;
  }
}