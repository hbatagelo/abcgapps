#include "window.hpp"

void Window::onCreate() {
  auto const &assetsPath{abcg::Application::getAssetsPath()};

  // Create program
  m_program =
      abcg::createOpenGLProgram({{.source = assetsPath + "imgproc.vert",
                                  .stage = abcg::ShaderStage::Vertex},
                                 {.source = assetsPath + "imgproc.frag",
                                  .stage = abcg::ShaderStage::Fragment}});

  // Quad data
  struct Vertex {
    glm::vec2 position;
    glm::vec2 texCoord;
  };

  std::array const vertices{Vertex{.position = {-1, +1}, .texCoord = {0, 1}},
                            Vertex{.position = {-1, -1}, .texCoord = {0, 0}},
                            Vertex{.position = {+1, +1}, .texCoord = {1, 1}},
                            Vertex{.position = {+1, -1}, .texCoord = {1, 0}}};
  // Generate VBO
  abcg::glGenBuffers(1, &m_VBO);
  abcg::glBindBuffer(GL_ARRAY_BUFFER, m_VBO);
  abcg::glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices.data(),
                     GL_STATIC_DRAW);

  // Create VAO
  abcg::glGenVertexArrays(1, &m_VAO);
  abcg::glBindVertexArray(m_VAO);

  // Set up vertex attributes
  auto setAttribute{[](auto program, auto const &attributeName, auto numFloats,
                       auto stride, auto offset) {
    auto const location{abcg::glGetAttribLocation(program, attributeName)};
    abcg::glEnableVertexAttribArray(location);
    abcg::glVertexAttribPointer(location, numFloats, GL_FLOAT, GL_FALSE, stride,
                                reinterpret_cast<void *>(offset));
  }};

  auto const stride{sizeof(Vertex)};
  setAttribute(m_program, "inPosition", 2, stride, 0);
  setAttribute(m_program, "inTexCoord", 2, stride, offsetof(Vertex, texCoord));

  // End of binding to current VAO
  abcg::glBindBuffer(GL_ARRAY_BUFFER, 0);
  abcg::glBindVertexArray(0);

  // Load texture
  m_texture = abcg::loadOpenGLTexture({.path = assetsPath + "naturalpark.jpg"});

  abcg::glActiveTexture(GL_TEXTURE0);
  abcg::glBindTexture(GL_TEXTURE_2D, m_texture);

  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  abcg::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}

void Window::onPaint() {
  abcg::glViewport(0, 0, m_viewportSize.x, m_viewportSize.y);

  abcg::glUseProgram(m_program);
  abcg::glBindVertexArray(m_VAO);

  auto const brightnessLoc{abcg::glGetUniformLocation(m_program, "brightness")};
  auto const contrastLoc{abcg::glGetUniformLocation(m_program, "contrast")};
  auto const saturationLoc{abcg::glGetUniformLocation(m_program, "saturation")};
  auto const kernelSizeLoc{abcg::glGetUniformLocation(m_program, "kernelSize")};
  auto const kernelStdDevLoc{
      abcg::glGetUniformLocation(m_program, "kernelStdDev")};
  auto const kernelSpreadLoc{
      abcg::glGetUniformLocation(m_program, "kernelSpread")};
  auto const bloomEnabledLoc{
      abcg::glGetUniformLocation(m_program, "bloomEnabled")};
  auto const bloomStrengthLoc{
      abcg::glGetUniformLocation(m_program, "bloomStrength")};

  abcg::glUniform1f(brightnessLoc, (m_brightness * 2.0f) - 1.0f);
  abcg::glUniform1f(contrastLoc, m_contrast * 2.0f);
  abcg::glUniform1f(saturationLoc, m_saturation);
  abcg::glUniform1i(kernelSizeLoc, m_kernelSize);
  // We let the user decide how many sigmas are to be used, and then compute the
  // standard deviation based on the fact that a kernel of size 6*sigma by
  // 6*sigma captures more than 99% of the distribution.
  abcg::glUniform1f(kernelStdDevLoc, m_kernelSize / m_kernelSigmas);
  abcg::glUniform1f(kernelSpreadLoc, m_kernelSpread);
  abcg::glUniform1i(bloomEnabledLoc, m_bloomEnabled);
  abcg::glUniform1f(bloomStrengthLoc, m_bloomStrength);

  // Draw quad
  abcg::glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

  abcg::glBindVertexArray(0);
  abcg::glUseProgram(0);
}

void Window::onPaintUI() {
  abcg::OpenGLWindow::onPaintUI();
  {
    auto const widgetSize{ImVec2(278, 280)};
    ImGui::SetNextWindowPos(ImVec2(m_viewportSize.x - widgetSize.x - 5, 5));
    ImGui::SetNextWindowSize(widgetSize);
    ImGui::Begin("Widget window", nullptr, ImGuiWindowFlags_NoDecoration);

    ImGui::Text("Basic adjustments:");
    ImGui::SliderFloat("Brightness", &m_brightness, 0.0f, 1.0f, "%.1f");
    ImGui::SliderFloat("Contrast", &m_contrast, 0.0f, 1.0f, "%.1f");
    ImGui::SliderFloat("Saturation", &m_saturation, 0.0f, 1.0f, "%.1f");

    ImGui::Text("Gaussian blur (kernel settings):");

    ImGui::SliderInt("Size", &m_kernelSize, 1, 21);
    if (m_kernelSize % 2 == 0) {
      ++m_kernelSize;
    }
    ImGui::SliderFloat("Sigmas", &m_kernelSigmas, 1.0f, 6.0f, "%.1f");
    ImGui::SliderFloat("Spread", &m_kernelSpread, 1.0f, 2.0f, "%.1f");

    ImGui::Text("Bloom:");
    ImGui::Checkbox("Enabled", &m_bloomEnabled);
    ImGui::BeginDisabled(!m_bloomEnabled);
    ImGui::SliderFloat("Strength", &m_bloomStrength, 0.0f, 1.0f, "%.1f");
    ImGui::EndDisabled();

    ImGui::End();
  }
}

void Window::onResize(glm::ivec2 const &size) { m_viewportSize = size; }

void Window::onDestroy() {
  abcg::glDeleteProgram(m_program);
  abcg::glDeleteBuffers(1, &m_VBO);
  abcg::glDeleteVertexArrays(1, &m_VAO);
  abcg::glDeleteTextures(1, &m_texture);
}
