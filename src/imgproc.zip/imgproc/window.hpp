#ifndef WINDOW_HPP_
#define WINDOW_HPP_

#include "abcgOpenGL.hpp"

class Window : public abcg::OpenGLWindow {
protected:
  void onCreate() override;
  void onPaint() override;
  void onPaintUI() override;
  void onResize(glm::ivec2 const &size) override;
  void onDestroy() override;

private:
  glm::ivec2 m_viewportSize{};

  GLuint m_VAO{};
  GLuint m_VBO{};
  GLuint m_program{};

  GLuint m_texture{};

  // Basic image adjustments
  float m_brightness{0.5f};
  float m_contrast{0.5f};
  float m_saturation{1.0f};

  // Gaussian blur
  int m_kernelSize{5};
  float m_kernelSigmas{2.0f};
  float m_kernelSpread{1.0f};

  void loadTexture(std::string_view path);
};

#endif